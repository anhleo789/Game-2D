namespace UnityEngine.Timeline
{
    //used to tell Signal Handler inspector to use a special drawer for UnityEvent
    class CustomSignalEventDrawer : PropertyAttribute { }
}
